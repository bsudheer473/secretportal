"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLogRepository = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
/**
 * Repository for managing audit log entries in DynamoDB
 * Implements exponential backoff retry logic for throttling errors
 */
class AuditLogRepository {
    constructor(tableName, region) {
        this.maxRetries = 3;
        this.retryDelays = [100, 200, 400]; // milliseconds
        const client = new client_dynamodb_1.DynamoDBClient({ region: region || process.env.AWS_REGION });
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
        this.tableName = tableName;
    }
    /**
     * Execute a command with exponential backoff retry logic
     */
    async executeWithRetry(command, operation) {
        let lastError;
        for (let attempt = 0; attempt < this.maxRetries; attempt++) {
            try {
                const result = await this.docClient.send(command);
                return result;
            }
            catch (error) {
                lastError = error;
                // Don't retry on resource not found
                if (error instanceof client_dynamodb_1.ResourceNotFoundException ||
                    error.name === 'ResourceNotFoundException') {
                    throw error;
                }
                // Retry on throttling errors
                if (error.name === 'ThrottlingException' ||
                    error.name === 'ProvisionedThroughputExceededException') {
                    if (attempt < this.maxRetries - 1) {
                        const delay = this.retryDelays[attempt];
                        console.log(`${operation} throttled, retrying in ${delay}ms (attempt ${attempt + 1}/${this.maxRetries})`);
                        await this.sleep(delay);
                        continue;
                    }
                }
                // For other errors, throw immediately
                throw error;
            }
        }
        throw lastError || new Error(`${operation} failed after ${this.maxRetries} attempts`);
    }
    sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    /**
     * Create a new audit log entry
     * Automatically sets TTL to 90 days from now
     */
    async create(entry) {
        // Calculate TTL (90 days from now in seconds since epoch)
        const ttl = Math.floor(Date.now() / 1000) + 90 * 24 * 60 * 60;
        const command = new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: {
                ...entry,
                ttl,
            },
        });
        await this.executeWithRetry(command, 'create audit log');
    }
    /**
     * Query audit log entries by secret ID
     * Returns entries sorted by timestamp in descending order (most recent first)
     */
    async queryBySecretId(secretId, limit, lastEvaluatedKey) {
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            KeyConditionExpression: 'secretId = :secretId',
            ExpressionAttributeValues: { ':secretId': secretId },
            ScanIndexForward: false, // Sort in descending order (most recent first)
            Limit: limit,
            ExclusiveStartKey: lastEvaluatedKey,
        });
        const result = await this.executeWithRetry(command, 'queryBySecretId');
        return {
            items: result.Items || [],
            lastEvaluatedKey: result.LastEvaluatedKey,
        };
    }
}
exports.AuditLogRepository = AuditLogRepository;
//# sourceMappingURL=audit-log-repository.js.map