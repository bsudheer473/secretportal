import { AuditLogEntry } from '@secrets-portal/shared-types';
/**
 * Repository for managing audit log entries in DynamoDB
 * Implements exponential backoff retry logic for throttling errors
 */
export declare class AuditLogRepository {
    private readonly docClient;
    private readonly tableName;
    private readonly maxRetries;
    private readonly retryDelays;
    constructor(tableName: string, region?: string);
    /**
     * Execute a command with exponential backoff retry logic
     */
    private executeWithRetry;
    private sleep;
    /**
     * Create a new audit log entry
     * Automatically sets TTL to 90 days from now
     */
    create(entry: AuditLogEntry): Promise<void>;
    /**
     * Query audit log entries by secret ID
     * Returns entries sorted by timestamp in descending order (most recent first)
     */
    queryBySecretId(secretId: string, limit?: number, lastEvaluatedKey?: Record<string, any>): Promise<{
        items: AuditLogEntry[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
}
//# sourceMappingURL=audit-log-repository.d.ts.map