#!/bin/bash

# Quick deployment script
# Run this on your local machine after setting up AWS infrastructure

if [ -z "$1" ]; then
    echo "Usage: ./quick-deploy.sh PUBLIC_IP"
    echo "Example: ./quick-deploy.sh 54.123.45.67"
    exit 1
fi

PUBLIC_IP=$1
KEY_FILE="secrets-portal-key.pem"

if [ ! -f "$KEY_FILE" ]; then
    echo "Error: $KEY_FILE not found!"
    echo "Make sure you have the EC2 key pair in this directory"
    exit 1
fi

echo "Deploying to $PUBLIC_IP..."

# Copy backend
echo "Copying backend..."
scp -i $KEY_FILE -r backend ubuntu@$PUBLIC_IP:~/packages/backend-express/

# Copy frontend
echo "Copying frontend..."
ssh -i $KEY_FILE ubuntu@$PUBLIC_IP "sudo mkdir -p /var/www/secrets-portal"
scp -i $KEY_FILE -r frontend/* ubuntu@$PUBLIC_IP:~/frontend-temp/
ssh -i $KEY_FILE ubuntu@$PUBLIC_IP "sudo cp -r ~/frontend-temp/* /var/www/secrets-portal/ && rm -rf ~/frontend-temp"

echo "✅ Deployment complete!"
echo "Access: http://$PUBLIC_IP"
