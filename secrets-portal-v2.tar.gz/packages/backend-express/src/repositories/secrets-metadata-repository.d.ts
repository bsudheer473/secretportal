import { SecretMetadata, Environment } from '../types';
/**
 * Repository for managing secrets metadata in DynamoDB
 * Implements exponential backoff retry logic for throttling errors
 */
export declare class SecretsMetadataRepository {
    private readonly docClient;
    private readonly tableName;
    private readonly maxRetries;
    private readonly retryDelays;
    constructor(tableName: string, region?: string);
    /**
     * Execute a command with exponential backoff retry logic
     */
    private executeWithRetry;
    private sleep;
    /**
     * Create a new secret metadata entry
     */
    create(metadata: SecretMetadata): Promise<void>;
    /**
     * Update an existing secret metadata entry
     */
    update(secretId: string, updates: Partial<Omit<SecretMetadata, 'secretId'>>): Promise<void>;
    /**
     * Get a secret metadata entry by ID
     */
    get(secretId: string): Promise<SecretMetadata | null>;
    /**
     * List all secret metadata entries
     */
    list(limit?: number, lastEvaluatedKey?: Record<string, any>): Promise<{
        items: SecretMetadata[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
    /**
     * Query secrets by application and optionally by environment
     */
    queryByApplication(application: string, environment?: Environment, limit?: number, lastEvaluatedKey?: Record<string, any>): Promise<{
        items: SecretMetadata[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
    /**
     * Query secrets by environment
     */
    queryByEnvironment(environment: Environment, limit?: number, lastEvaluatedKey?: Record<string, any>): Promise<{
        items: SecretMetadata[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
}
//# sourceMappingURL=secrets-metadata-repository.d.ts.map